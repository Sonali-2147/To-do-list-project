const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

let input = '';

const todos = ['Web course', 'ML course'];

const promptUser = () => {
  rl.question('What would you like to do? ', (answer) => {
    input = answer;
    processInput();
  });
};

const processInput = () => {
  if (input === 'quit' || input === 'q') {
    console.log("OK, Quit the App!");
    rl.close();
  } else if (input === 'list') {
    console.log('*******');
    for (let i = 0; i < todos.length; i++) {
      console.log(`${i}: ${todos[i]}`);
    }
    console.log('*******');
    promptUser();
  } else if (input === 'new') {
    rl.question('OK, What is the new to do? ', (answer) => {
      const newTodo = answer;
      todos.push(newTodo);
      console.log(`${newTodo} added to the list!`);
      promptUser();
    });
  } else if (input === 'delete') {
    rl.question('Enter index to delete: ', (answer) => {
      const index = parseInt(answer);
      if (!Number.isNaN(index) && index >= 0 && index < todos.length) {
        const deleted = todos.splice(index, 1);
        console.log(`OK, deleted! ${deleted[0]}`);
      } else {
        console.log('Unknown index or out of range');
      }
      promptUser();
    });
  } else {
    console.log('Unknown command');
    promptUser();
  }
};

promptUser();
